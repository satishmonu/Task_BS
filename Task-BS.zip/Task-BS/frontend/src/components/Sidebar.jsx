import React from "react";
import { NavLink, useNavigate } from "react-router-dom";

export default function Sidebar() {
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  return (
    <aside style={styles.sidebar}>
      <h2 style={styles.logo}>Admin Dashboard</h2>

      <nav style={styles.nav}>
        <NavItem to="/dashboard" label="Dashboard" />
        <NavItem to="/profile" label="Profile" />
        <NavItem to="/settings" label="Settings" />
      </nav>

      <button onClick={logout} style={styles.logout}>
        Logout
      </button>
    </aside>
  );
}

function NavItem({ to, label }) {
  return (
    <NavLink
      to={to}
      style={({ isActive }) => ({
        ...styles.link,
        background: isActive ? "#1e293b" : "transparent",
      })}
    >
      {label}
    </NavLink>
  );
}

const styles = {
  sidebar: {
    width: 240,
    background: "#0f172a",
    color: "#fff",
    display: "flex",
    flexDirection: "column",
    padding: 20,
  },
  logo: {
    margin: "0 0 24px 0",
    fontSize: 20,
    fontWeight: 700,
  },
  nav: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
    gap: 6,
  },
  link: {
    color: "#cbd5f5",
    textDecoration: "none",
    padding: "10px 12px",
    borderRadius: 6,
    fontWeight: 500,
  },
  logout: {
    background: "#ef4444",
    color: "#fff",
    border: "none",
    borderRadius: 6,
    padding: "10px",
    cursor: "pointer",
  },
};
