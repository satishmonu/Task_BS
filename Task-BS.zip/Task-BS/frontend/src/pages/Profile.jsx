import React from "react";
import DashboardLayout from "../components/DashboardLayout";

export default function Profile() {
  return (
    <DashboardLayout>
      <h1>Profile Page</h1>
      <p>This page uses the same sidebar layout.</p>
    </DashboardLayout>
  );
}
