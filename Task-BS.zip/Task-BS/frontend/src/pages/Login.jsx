import React, { useState } from "react";
import API from "../services/api";
import { useNavigate } from "react-router-dom";
import { loginUser } from "../services/authService";

export default function Login() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [serverError, setServerError] = useState("");

  // -----------------------------
  // Validation
  // -----------------------------
  const validate = () => {
    const newErrors = {};

    if (!form.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      newErrors.email = "Enter a valid email address";
    }

    if (!form.password) {
      newErrors.password = "Password is required";
    } else if (form.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // -----------------------------
  // Submit Handler
  // -----------------------------
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (loading) return;

    setServerError("");

    if (!validate()) return;

    try {
      setLoading(true);
      const res = await loginUser({
        email: form.email.trim(),
        password: form.password,
      });
      localStorage.setItem("token", res.data.token);
      navigate("/dashboard");
    } catch (err) {
      setServerError(
        err.response?.data?.message || "Invalid email or password"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <form onSubmit={handleSubmit} style={styles.card} noValidate>
        <h1 style={styles.title}>Admin Login</h1>
        <p style={styles.subtitle}>Login to your account</p>

        {/* Email */}
        <div style={styles.field}>
          <label htmlFor="email" style={styles.label}>
            Email address
          </label>
          <input
            id="email"
            type="email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            style={{
              ...styles.input,
              borderColor: errors.email ? "#ef4444" : "#cbd5f5",
            }}
            aria-invalid={!!errors.email}
            aria-describedby="email-error"
          />
          {errors.email && (
            <span id="email-error" style={styles.error}>
              {errors.email}
            </span>
          )}
        </div>

        {/* Password */}
        <div style={styles.field}>
          <label htmlFor="password" style={styles.label}>
            Password
          </label>
          <input
            id="password"
            type="password"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            style={{
              ...styles.input,
              borderColor: errors.password ? "#ef4444" : "#cbd5f5",
            }}
            aria-invalid={!!errors.password}
            aria-describedby="password-error"
          />
          {errors.password && (
            <span id="password-error" style={styles.error}>
              {errors.password}
            </span>
          )}
        </div>

        {/* Server Error */}
        {serverError && (
          <div style={styles.serverError} role="alert">
            {serverError}
          </div>
        )}

        {/* Submit Button */}
        <button
          type="submit"
          style={{
            ...styles.button,
            opacity: loading ? 0.7 : 1,
          }}
          disabled={loading}
        >
          {loading ? "Signing in..." : "Login"}
        </button>
      </form>
    </div>
  );
}

//
// Styles (simple, responsive, clean)
//
const styles = {
  container: {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    background: "linear-gradient(135deg,#e0e7ff,#f8fafc)",
    padding: 16,
  },
  card: {
    width: "100%",
    maxWidth: 420,
    background: "#fff",
    borderRadius: 12,
    padding: 32,
    boxShadow: "0 20px 40px rgba(0,0,0,0.1)",
  },
  title: {
    margin: 0,
    fontSize: 28,
    fontWeight: 700,
    textAlign: "center",
  },
  subtitle: {
    textAlign: "center",
    color: "#64748b",
    marginBottom: 24,
  },
  field: {
    marginBottom: 16,
  },
  label: {
    display: "block",
    marginBottom: 6,
    fontWeight: 500,
  },
  input: {
    width: "100%",
    padding: "12px 14px",
    fontSize: 14,
    borderRadius: 8,
    border: "1px solid #cbd5f5",
    outline: "none",
  },
  error: {
    color: "#ef4444",
    fontSize: 12,
    marginTop: 4,
    display: "block",
  },
  serverError: {
    background: "#fee2e2",
    color: "#991b1b",
    padding: 10,
    borderRadius: 8,
    fontSize: 14,
    marginBottom: 16,
  },
  button: {
    width: "100%",
    padding: 12,
    fontSize: 16,
    fontWeight: 600,
    borderRadius: 8,
    border: "none",
    cursor: "pointer",
    background: "#4f46e5",
    color: "#fff",
  },
};
