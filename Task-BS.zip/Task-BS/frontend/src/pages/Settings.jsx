import React from "react";
import DashboardLayout from "../components/DashboardLayout";

export default function Settings() {
  return (
    <DashboardLayout>
      <h1>Settings Page</h1>
      <p>Settings content goes here.</p>
    </DashboardLayout>
  );
}
