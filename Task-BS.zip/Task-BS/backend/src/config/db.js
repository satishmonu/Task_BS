import mysql from "mysql2";

export const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "fssUser@2023",
  database: "react_node_app",
});

db.connect((err) => {
  if (err) console.error(err);
  else console.log("MySQL Connected");
});
