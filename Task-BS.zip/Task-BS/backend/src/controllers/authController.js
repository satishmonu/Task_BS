import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { db } from "../config/db.js";

export const register = (req, res) => {
  const { name, email, password } = req.body;
  const hashed = bcrypt.hashSync(password, 10);

  db.query(
    "INSERT INTO users (name,email,password) VALUES (?,?,?)",
    [name, email, hashed],
    (err) => {
      if (err) return res.status(400).json({ message: "User exists" });
      res.json({ message: "Registered successfully" });
    }
  );
};

export const login = (req, res) => {
  const { email, password } = req.body;

  console.log("LOGIN INPUT:", email, password);

  db.query("SELECT * FROM users WHERE email=?", [email], (err, rows) => {
    console.log("DB ERROR:", err);
    console.log("DB ROWS:", rows);

    if (!rows || rows.length === 0) {
      console.log("❌ USER NOT FOUND");
      return res.status(401).json({ message: "Invalid" });
    }

    const user = rows[0];

    const match = bcrypt.compareSync(password, user.password);
    console.log("PASSWORD MATCH:", match);
    console.log("DB PASSWORD:", user.password);

    if (!match) {
      console.log("❌ PASSWORD MISMATCH");
      return res.status(401).json({ message: "Invalid" });
    }

    const token = jwt.sign(
      {
        id: user.id,
        email: user.email,
        name: user.name,
      },
      process.env.JWT_SECRET,
      { expiresIn: "1d" }
    );

    console.log("✅ LOGIN SUCCESS");

    res.json({ token });
  });
};
